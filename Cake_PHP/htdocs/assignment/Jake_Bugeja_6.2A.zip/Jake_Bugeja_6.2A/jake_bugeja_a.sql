-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2022 at 04:34 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `jake_bugeja_a`
--

-- --------------------------------------------------------

--
-- Table structure for table `investments`
--

CREATE TABLE `investments` (
  `id` int(11) NOT NULL,
  `share` int(11) NOT NULL,
  `bought_at` int(11) NOT NULL,
  `note` varchar(100) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `privacy` tinyint(1) NOT NULL DEFAULT 0,
  `image` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ticker_id` int(11) NOT NULL,
  `like_counter` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `investments`
--

INSERT INTO `investments` (`id`, `share`, `bought_at`, `note`, `created`, `privacy`, `image`, `user_id`, `ticker_id`, `like_counter`) VALUES
(76, 2, 350, 'From Etoro', '2022-01-15 17:03:51', 1, '', 10, 2, 3),
(77, 1, 2000, 'From WeBull', '2022-01-15 17:05:43', 0, '', 10, 1, 0),
(80, 1, 1300, 'From Etoro', '2022-01-15 17:46:54', 1, '', 11, 5, 7),
(81, 1, 1000, 'From Etoro', '2022-01-15 17:47:45', 1, '', 11, 4, 0),
(82, 2, 500, 'From WeBull', '2022-01-16 11:52:47', 1, '', 11, 2, 3),
(83, 5, 2000, 'From Etoro', '2022-01-16 12:18:15', 1, '', 11, 5, 0),
(84, 5, 2000, 'From Etoro', '2022-01-16 12:18:49', 1, '', 11, 5, 2),
(85, 1, 500, 'From WeBull', '2022-01-16 14:05:44', 1, '', 10, 4, 1),
(86, 3, 340, 'From Etoro', '2022-01-16 14:18:55', 1, '', 10, 2, 0),
(87, 3, 890, 'From Etoro', '2022-01-16 14:20:05', 1, '', 10, 4, 1),
(88, 3, 890, 'From Etoro', '2022-01-16 14:21:32', 1, '', 10, 4, 2),
(89, 1, 890, 'From Etoro', '2022-01-16 14:21:46', 1, '', 10, 2, 1),
(90, 1, 890, 'From Etoro', '2022-01-16 14:25:02', 1, '', 10, 2, 2),
(91, 1, 1900, 'From Etoro', '2022-01-16 14:25:18', 1, '', 10, 1, 3),
(92, 2, 1300, 'From WeBull', '2022-01-16 14:51:36', 1, '', 10, 2, 6),
(102, 2, 2000, 'From Etoro', '2022-01-16 21:31:46', 0, '', 10, 1, 0),
(103, 1, 2000, 'From WeBull', '2022-01-16 21:33:46', 0, '', 10, 5, 0),
(104, 1, 699, 'From Etoro', '2022-01-16 21:55:24', 0, '', 11, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tickers`
--

CREATE TABLE `tickers` (
  `id` int(11) NOT NULL,
  `ticker` varchar(35) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tickers`
--

INSERT INTO `tickers` (`id`, `ticker`) VALUES
(1, 'Apple'),
(2, 'Microsoft'),
(3, 'Alphabet'),
(4, 'Amazon'),
(5, 'Tesla');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `investments`
--
ALTER TABLE `investments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ticker_id_fk` (`ticker_id`),
  ADD KEY `user_id_fk2` (`user_id`);

--
-- Indexes for table `tickers`
--
ALTER TABLE `tickers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `investments`
--
ALTER TABLE `investments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=105;

--
-- AUTO_INCREMENT for table `tickers`
--
ALTER TABLE `tickers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `investments`
--
ALTER TABLE `investments`
  ADD CONSTRAINT `ticker_id_fk` FOREIGN KEY (`ticker_id`) REFERENCES `tickers` (`id`),
  ADD CONSTRAINT `user_id_fk2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
