<?php
//echo "<a href='".$clientAuth->createAuthUrl()."'>Google Login</a>";
?>
<!DOCTYPE html>
<html>
<head>

</head>
<body>
<p>This is a paragraph.</p>

<?php

?>


<!--<script src="google.js"></script>-->


</body>
</html>