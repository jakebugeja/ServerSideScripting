<?php
   namespace App\Controller;
   use App\Controller\AppController;
   use Cake\Log\Log;
   
   class LogsController extends AppController{
       /*
1. New trade
2. Like/Dislike a trade
3. Logins
4. Logout
Details to log
§ Date & Time
§ User (if logged in)
§ IP Address
§ Message
§ User/Trade ID if applicable
§ Any other information you believe is important to log

els' => ['warning', 'error', 'critical', 'alert', 'emergency'],
       */
      public function index(){
         
      }
   }
?>