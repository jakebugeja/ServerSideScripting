
 Something is written in a log file.<br> Either in Check log file logs\debug.log
 <br>Either in Check log file logs\emergency.log
 <br>Either in Check log file logs\error.log 